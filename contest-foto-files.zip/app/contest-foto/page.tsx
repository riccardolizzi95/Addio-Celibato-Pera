'use client'

import { useState, useEffect, useRef } from 'react'

const TAVOLI = Array.from({ length: 9 }, (_, i) => i + 1)

interface Foto {
  id: string
  tavolo: number
  nome_persona: string
  titolo: string
  file_path: string
  is_ufficiale: boolean
  contatore: number
  created_at: string
  public_url: string
}

type View = 'upload' | 'gallery'
type Msg = { type: 'success' | 'error'; text: string } | null

export default function ContestFotoPage() {
  const [view, setView] = useState<View>('upload')
  const [tavolo, setTavolo] = useState('')
  const [nomePersona, setNomePersona] = useState('')
  const [titolo, setTitolo] = useState('')
  const [file, setFile] = useState<File | null>(null)
  const [preview, setPreview] = useState<string | null>(null)
  const [loading, setLoading] = useState(false)
  const [msg, setMsg] = useState<Msg>(null)
  const [fotos, setFotos] = useState<Foto[]>([])
  const [galleryTavolo, setGalleryTavolo] = useState('')
  const [loadingGallery, setLoadingGallery] = useState(false)
  const [settingUfficiale, setSettingUfficiale] = useState<string | null>(null)
  const fileRef = useRef<HTMLInputElement>(null)

  // Pre-compila il tavolo dall'URL ?tavolo=X
  useEffect(() => {
    const params = new URLSearchParams(window.location.search)
    const t = params.get('tavolo')
    if (t && parseInt(t) >= 1 && parseInt(t) <= 9) setTavolo(t)
  }, [])

  function handleFileChange(e: React.ChangeEvent<HTMLInputElement>) {
    const f = e.target.files?.[0]
    if (!f) return
    setFile(f)
    setPreview(URL.createObjectURL(f))
  }

  async function handleUpload(e: React.FormEvent) {
    e.preventDefault()
    if (!tavolo || !nomePersona || !titolo || !file) {
      setMsg({ type: 'error', text: 'Compila tutti i campi e seleziona una foto.' })
      return
    }
    setLoading(true)
    setMsg(null)
    const fd = new FormData()
    fd.append('tavolo', tavolo)
    fd.append('nome_persona', nomePersona)
    fd.append('titolo', titolo)
    fd.append('foto', file)
    try {
      const r = await fetch('/api/contest-foto/upload', { method: 'POST', body: fd })
      const data = await r.json()
      if (!r.ok) throw new Error(data.error)
      setMsg({ type: 'success', text: '✅ Foto caricata! Puoi caricarne altre o selezionare quella ufficiale nella Galleria.' })
      setFile(null)
      setPreview(null)
      setTitolo('')
      if (fileRef.current) fileRef.current.value = ''
    } catch (err) {
      setMsg({ type: 'error', text: `❌ ${err instanceof Error ? err.message : 'Errore'}` })
    } finally {
      setLoading(false)
    }
  }

  async function loadGallery() {
    if (!galleryTavolo) return
    setLoadingGallery(true)
    setFotos([])
    setMsg(null)
    try {
      const r = await fetch(`/api/contest-foto/foto?tavolo=${galleryTavolo}`)
      const data = await r.json()
      if (!r.ok) throw new Error(data.error)
      setFotos(data.foto)
    } catch (err) {
      setMsg({ type: 'error', text: err instanceof Error ? err.message : 'Errore' })
    } finally {
      setLoadingGallery(false)
    }
  }

  async function handleSetUfficiale(fotoId: string) {
    setSettingUfficiale(fotoId)
    setMsg(null)
    try {
      const r = await fetch('/api/contest-foto/set-ufficiale', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ foto_id: fotoId, tavolo: parseInt(galleryTavolo) }),
      })
      const data = await r.json()
      if (!r.ok) throw new Error(data.error)
      setMsg({ type: 'success', text: '🏆 Foto ufficiale selezionata e salvata su Drive!' })
      setFotos(prev => prev.map(f => ({ ...f, is_ufficiale: f.id === fotoId })))
    } catch (err) {
      setMsg({ type: 'error', text: err instanceof Error ? err.message : 'Errore' })
    } finally {
      setSettingUfficiale(null)
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#1a1a2e] via-[#16213e] to-[#0f3460] pb-10">
      {/* Header */}
      <div className="text-center pt-8 pb-4 px-4">
        <div className="text-4xl mb-2">💍</div>
        <h1 className="text-white text-2xl font-bold tracking-wide">Contest Fotografico</h1>
        <p className="text-slate-400 text-sm mt-1">Yas ♥ Pera • Matrimonio 2025</p>
      </div>

      {/* Tabs */}
      <div className="flex gap-2 px-4 pb-4 max-w-lg mx-auto">
        <button
          onClick={() => { setView('upload'); setMsg(null) }}
          className={`flex-1 py-2.5 rounded-xl text-sm font-medium transition-all ${
            view === 'upload'
              ? 'bg-gradient-to-r from-red-600 to-red-700 text-white font-bold'
              : 'bg-white/10 text-slate-400 border border-white/10'
          }`}
        >
          📤 Carica foto
        </button>
        <button
          onClick={() => { setView('gallery'); setMsg(null) }}
          className={`flex-1 py-2.5 rounded-xl text-sm font-medium transition-all ${
            view === 'gallery'
              ? 'bg-gradient-to-r from-red-600 to-red-700 text-white font-bold'
              : 'bg-white/10 text-slate-400 border border-white/10'
          }`}
        >
          🖼️ Galleria & Selezione
        </button>
      </div>

      {/* Card */}
      <div className="mx-4 max-w-lg lg:mx-auto bg-white/5 backdrop-blur border border-white/10 rounded-2xl p-5">

        {/* Alert */}
        {msg && (
          <div className={`mb-4 px-4 py-3 rounded-xl text-sm ${
            msg.type === 'success'
              ? 'bg-green-500/15 border border-green-500/40 text-green-300'
              : 'bg-red-500/15 border border-red-500/40 text-red-300'
          }`}>
            {msg.text}
          </div>
        )}

        {/* ── UPLOAD ── */}
        {view === 'upload' && (
          <form onSubmit={handleUpload} className="flex flex-col gap-1">
            <label className="text-slate-300 text-xs font-semibold mt-3 mb-1">Numero tavolo</label>
            <select
              className="bg-[#1a2744] border border-white/20 text-white rounded-lg px-3 py-2.5 text-base"
              value={tavolo}
              onChange={e => setTavolo(e.target.value)}
              required
            >
              <option value="">— Seleziona tavolo —</option>
              {TAVOLI.map(t => <option key={t} value={t}>Tavolo {t}</option>)}
            </select>

            <label className="text-slate-300 text-xs font-semibold mt-3 mb-1">Il tuo nome</label>
            <input
              className="bg-white/8 border border-white/20 text-white rounded-lg px-3 py-2.5 text-base placeholder:text-slate-500 outline-none focus:border-red-500"
              type="text" placeholder="Es. Mario Rossi"
              value={nomePersona} onChange={e => setNomePersona(e.target.value)}
              required maxLength={50}
            />

            <label className="text-slate-300 text-xs font-semibold mt-3 mb-1">Titolo della foto</label>
            <input
              className="bg-white/8 border border-white/20 text-white rounded-lg px-3 py-2.5 text-base placeholder:text-slate-500 outline-none focus:border-red-500"
              type="text" placeholder="Es. Il brindisi del tavolo"
              value={titolo} onChange={e => setTitolo(e.target.value)}
              required maxLength={80}
            />

            <label className="text-slate-300 text-xs font-semibold mt-3 mb-1">Seleziona foto</label>
            <input
              ref={fileRef}
              className="text-slate-300 text-sm file:mr-3 file:py-1.5 file:px-3 file:rounded-lg file:border-0 file:bg-red-700 file:text-white file:text-sm file:cursor-pointer"
              type="file" accept="image/*"
              onChange={handleFileChange}
              required
            />

            {preview && (
              <div className="mt-3 rounded-xl overflow-hidden">
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img src={preview} alt="preview" className="w-full max-h-56 object-cover" />
              </div>
            )}

            <button
              type="submit"
              disabled={loading}
              className={`mt-5 py-3 rounded-xl text-base font-bold transition-all ${
                loading
                  ? 'bg-slate-600 text-slate-400 cursor-not-allowed'
                  : 'bg-gradient-to-r from-red-600 to-red-700 text-white active:scale-95'
              }`}
            >
              {loading ? '⏳ Caricamento...' : '📤 Carica foto'}
            </button>

            <p className="text-slate-500 text-xs text-center mt-2">
              Puoi caricare quante foto vuoi. Poi nella <strong className="text-slate-400">Galleria</strong> scegli quella ufficiale per il contest.
            </p>
          </form>
        )}

        {/* ── GALLERY ── */}
        {view === 'gallery' && (
          <div>
            <div className="flex gap-2 mb-4">
              <select
                className="flex-1 bg-[#1a2744] border border-white/20 text-white rounded-lg px-3 py-2.5 text-base"
                value={galleryTavolo}
                onChange={e => setGalleryTavolo(e.target.value)}
              >
                <option value="">— Seleziona tavolo —</option>
                {TAVOLI.map(t => <option key={t} value={t}>Tavolo {t}</option>)}
              </select>
              <button
                onClick={loadGallery}
                disabled={!galleryTavolo || loadingGallery}
                className={`px-4 rounded-xl font-semibold text-sm transition-all ${
                  galleryTavolo && !loadingGallery
                    ? 'bg-red-700 text-white active:scale-95'
                    : 'bg-slate-700 text-slate-400 cursor-not-allowed'
                }`}
              >
                {loadingGallery ? '⏳' : '🔍 Carica'}
              </button>
            </div>

            {fotos.length === 0 && !loadingGallery && galleryTavolo && (
              <p className="text-slate-500 text-center py-6 text-sm">Nessuna foto ancora per questo tavolo.</p>
            )}

            <div className="flex flex-col gap-4">
              {fotos.map(f => (
                <div
                  key={f.id}
                  className={`rounded-xl overflow-hidden border ${
                    f.is_ufficiale
                      ? 'border-amber-400 bg-amber-400/8'
                      : 'border-white/10 bg-white/5'
                  }`}
                >
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img src={f.public_url} alt={f.titolo} className="w-full h-48 object-cover" loading="lazy" />
                  <div className="p-3">
                    <p className="text-white font-semibold text-sm">{f.titolo}</p>
                    <p className="text-slate-400 text-xs mt-0.5">📸 {f.nome_persona} · Tavolo {f.tavolo}</p>
                  </div>
                  {f.is_ufficiale ? (
                    <div className="mx-3 mb-3 py-2 rounded-lg bg-amber-400/20 border border-amber-400/50 text-amber-300 text-xs font-bold text-center">
                      🏆 FOTO UFFICIALE — partecipa al contest
                    </div>
                  ) : (
                    <button
                      onClick={() => handleSetUfficiale(f.id)}
                      disabled={settingUfficiale === f.id}
                      className={`mx-3 mb-3 w-[calc(100%-24px)] py-2 rounded-lg text-xs font-semibold border transition-all ${
                        settingUfficiale === f.id
                          ? 'bg-slate-700 text-slate-400 border-slate-600 cursor-not-allowed'
                          : 'bg-red-700/20 border-red-600/50 text-red-300 active:scale-95'
                      }`}
                    >
                      {settingUfficiale === f.id ? '⏳ Salvataggio...' : '⭐ Seleziona come foto ufficiale'}
                    </button>
                  )}
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  )
}