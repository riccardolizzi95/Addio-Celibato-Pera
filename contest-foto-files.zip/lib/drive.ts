import { google } from 'googleapis'
import { Readable } from 'stream'

const ROOT_FOLDER_ID = process.env.GOOGLE_DRIVE_ROOT_FOLDER_ID!

function getDriveClient() {
  const credentials = JSON.parse(process.env.GOOGLE_SERVICE_ACCOUNT_JSON!)
  const auth = new google.auth.GoogleAuth({
    credentials,
    scopes: ['https://www.googleapis.com/auth/drive'],
  })
  return google.drive({ version: 'v3', auth })
}

type DriveClient = ReturnType<typeof getDriveClient>

export async function getOrCreateFolder(
  drive: DriveClient,
  name: string,
  parentId: string
): Promise<string> {
  const res = await drive.files.list({
    q: `name='${name}' and '${parentId}' in parents and mimeType='application/vnd.google-apps.folder' and trashed=false`,
    fields: 'files(id)',
  })
  if (res.data.files && res.data.files.length > 0) {
    return res.data.files[0].id!
  }
  const folder = await drive.files.create({
    requestBody: {
      name,
      mimeType: 'application/vnd.google-apps.folder',
      parents: [parentId],
    },
    fields: 'id',
  })
  return folder.data.id!
}

export async function uploadFileToDrive(
  drive: DriveClient,
  buffer: Buffer,
  fileName: string,
  mimeType: string,
  folderId: string
): Promise<{ id: string; webViewLink: string }> {
  const stream = Readable.from(buffer)
  const res = await drive.files.create({
    requestBody: { name: fileName, parents: [folderId] },
    media: { mimeType, body: stream },
    fields: 'id,webViewLink',
  })
  return { id: res.data.id!, webViewLink: res.data.webViewLink ?? '' }
}

export async function moveFileInDrive(
  drive: DriveClient,
  fileId: string,
  newParentId: string,
  oldParentId: string
): Promise<void> {
  await drive.files.update({
    fileId,
    addParents: newParentId,
    removeParents: oldParentId,
    fields: 'id,parents',
  })
}

export async function getTavoloFolderId(drive: DriveClient, tavolo: number): Promise<string> {
  return getOrCreateFolder(drive, `Tavolo_${tavolo}`, ROOT_FOLDER_ID)
}

export async function getConfermateFolderId(drive: DriveClient, tavolo: number): Promise<string> {
  return getOrCreateFolder(drive, `Tavolo_${tavolo}_Confermate`, ROOT_FOLDER_ID)
}

export { getDriveClient }